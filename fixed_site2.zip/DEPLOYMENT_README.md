# NS Comforts – Deployment Guide

## Files in This Package

| File | Purpose |
|------|---------|
| `index.html` | Main website (SEO optimized) |
| `robots.txt` | Tells search engines what to crawl |
| `sitemap.xml` | Helps Google index all pages |
| `worker.js` | Cloudflare Worker (serves files + headers) |
| `wrangler.toml` | Cloudflare deployment config |

---

## Option 1: Cloudflare Pages (Recommended – Easiest)

1. Go to https://dash.cloudflare.com → **Pages** → **Create a project**
2. Choose **Direct Upload**
3. Upload these files: `index.html`, `robots.txt`, `sitemap.xml`
4. Click **Deploy**
5. Your site will be live at `https://nscomforts.pages.dev` (or your custom domain)

---

## Option 2: Cloudflare Workers (Current Setup)

### Prerequisites
```bash
npm install -g wrangler
wrangler login
```

### Deploy
```bash
wrangler deploy
```

---

## After Deployment – SEO Checklist

- [ ] Submit `sitemap.xml` to Google Search Console:
      https://search.google.com/search-console
      → Add Property → Enter your URL → Submit sitemap: `/sitemap.xml`

- [ ] Submit to Bing Webmaster Tools:
      https://www.bing.com/webmasters

- [ ] Verify Google Site Verification is active (already in index.html)

- [ ] Register on Google Business Profile:
      https://business.google.com
      → Add "NS Comforts" with address, phone, hours

- [ ] Add your hotel to:
  - MakeMyTrip
  - OYO / Goibibo
  - Booking.com
  - TripAdvisor

---

## Local SEO Tips

- Keep Google Business Profile updated with photos
- Encourage guests to leave Google Reviews
- Use the keyword "hotels in Nanjangud" in your GMB description
- Add Nanjangud temple as a nearby landmark in GMB

---

## Contact
- Phone: +91-9845029122
- Address: Building No. 3235/3108/A, Ooty Road, Near Hotel Surabhi, Nanjangud – 571301
