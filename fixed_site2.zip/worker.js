import { getAssetFromKV } from '@cloudflare/kv-asset-handler';

addEventListener('fetch', event => {
  event.respondWith(handleRequest(event));
});

async function handleRequest(event) {
  const url = new URL(event.request.url);

  // Redirect www to non-www
  if (url.hostname.startsWith('www.')) {
    return Response.redirect(`https://${url.hostname.slice(4)}${url.pathname}${url.search}`, 301);
  }

  // Force HTTPS
  if (url.protocol === 'http:') {
    return Response.redirect(`https://${url.hostname}${url.pathname}${url.search}`, 301);
  }

  try {
    // Serve robots.txt
    if (url.pathname === '/robots.txt') {
      const asset = await getAssetFromKV(event, { mapRequestToAsset: req => new Request(`${new URL(req.url).origin}/robots.txt`, req) });
      return new Response(asset.body, {
        headers: {
          'Content-Type': 'text/plain',
          'Cache-Control': 'public, max-age=86400',
        },
      });
    }

    // Serve sitemap.xml
    if (url.pathname === '/sitemap.xml') {
      const asset = await getAssetFromKV(event, { mapRequestToAsset: req => new Request(`${new URL(req.url).origin}/sitemap.xml`, req) });
      return new Response(asset.body, {
        headers: {
          'Content-Type': 'application/xml',
          'Cache-Control': 'public, max-age=86400',
        },
      });
    }

    // Serve main assets
    const asset = await getAssetFromKV(event);
    const response = new Response(asset.body, asset);

    // Add SEO & security headers
    response.headers.set('X-Content-Type-Options', 'nosniff');
    response.headers.set('X-Frame-Options', 'SAMEORIGIN');
    response.headers.set('X-XSS-Protection', '1; mode=block');
    response.headers.set('Referrer-Policy', 'strict-origin-when-cross-origin');
    response.headers.set('Cache-Control', 'public, max-age=3600, stale-while-revalidate=86400');
    response.headers.set('X-Robots-Tag', 'index, follow');

    return response;
  } catch (e) {
    // Fallback to index.html (SPA style)
    try {
      const asset = await getAssetFromKV(event, {
        mapRequestToAsset: req => new Request(`${new URL(req.url).origin}/index.html`, req),
      });
      return new Response(asset.body, { ...asset, status: 200 });
    } catch {
      return new Response('Page Not Found', { status: 404 });
    }
  }
}
